({
    doInit : function(component,event,helper) {
        console.log('Started');
        var vfOrigin = "https://greysanatomy-developer-edition.gus.force.com";
        //var vfOrigin = "https://" + component.get("v.vfHost"); 
        window.addEventListener("message", function(event) {
            console.log(event.origin);
            console.log(event.data.action);
            if (event.origin !== vfOrigin) {
                console.log('inside if');// Not the expected origin: Reject the message!
                return;
            }
            
            if(event.data.action == 'alohaCallingCAPTCHA' && event.data.alohaResponseCAPTCHA == 'NOK'){
                alert('Please do the captcha before submit!');
            }
            else if(event.data.action == 'alohaCallingCAPTCHA' && event.data.alohaResponseCAPTCHA == 'OK'){
                   
            }
        }, false);
    },
   
    cancel : function(component, event, helper) {
        
        
        
        
        //navigates to the case record in lightning app
        
        //$A.get('e.force:refreshView').fire(); 
    },
        
        
        
        save : function(component, event, helper) { 
            console.log('inside save');
            var ConnectedApp = event.getParams().response;
            console.log('Response--> '+ConnectedApp);
            console.log('fff'+event.getParams().response);    
            var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": ConnectedApp.id
                });
                navEvt.fire();
            	}

})
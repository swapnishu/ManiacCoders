({
	doInit: function(component, event, helper) {
       console.log("Inside child"+component.get("v.singleApp"));
    },
    // 
    getDetails: function(component, event, helper) {
        helper.getSingleConnectedApp(component);
    }
})
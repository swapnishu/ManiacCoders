({
	
    getSingleConnectedApp: function(component) {
        console.log("In get single helper");
		let action = component.get("c.getSingleMetadata");
        action.setParams({
            "metadataName" : component.get("v.singleApp")
        });
		action.setCallback(this,function(response){
			let state = response.getState();
            console.log('State= '+state);
			if(state === "SUCCESS") {
				//component.set("v.connectedApps",response.getReturnValue());
				console.log('res3 '+response.getReturnValue());
				console.log('response'+JSON.stringify(response.getReturnValue()));
                let app = response.getReturnValue();
                console.log('fullname'+app.fullName);
                console.log('type'+app.type);
                
			}
			else {
				console.log("error occured"+JSON.stringify(response.getError()));
				this.showErrorNotification(component,JSON.stringify(response.getError()));
			}
		});
		$A.enqueueAction(action);
    }
})
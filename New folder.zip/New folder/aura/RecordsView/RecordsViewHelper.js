({
	getConnectedApps : function(component) {
		console.log("In helper");
		let action = component.get("c.getConnectedApps");
		action.setCallback(this,function(response){
			let state = response.getState();
            console.log('State= '+state);
			if(state === "SUCCESS") {
				component.set("v.connectedApps",response.getReturnValue());
				console.log('response'+response.getReturnValue());
			}
			else {
				console.log("error occured"+JSON.stringify(response.getError()));
				this.showErrorNotification(component,JSON.stringify(response.getError()));
			}
		});
		$A.enqueueAction(action);
	},
	showErrorNotification: function(component, errMessage) {
		component.find('notifLib').showNotice({
            "variant": "error",
            "header": "Something has gone wrong!",
            "message": errMessage
        });
	}
})
({
	doInit : function(component, event, helper) {
        console.log("Session-->"+component.get("v.sessionId"));
		helper.getConnectedApps(component);
	}
})